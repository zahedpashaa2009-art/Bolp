package com.billiardbot

import kotlin.math.*

object Vision {
    private fun white(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return min(r, min(g, b)) > 175 && max(r, max(g, b)) - min(r, min(g, b)) < 50
    }

    private fun aimWhite(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return min(r, min(g, b)) > 190 && max(r, max(g, b)) - min(r, min(g, b)) < 45
    }

    /** Pixels painted by our own overlay (lime green). */
    fun isOv(c: Int): Boolean {
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return g > 200 && r < 90 && b < 130
    }

    private fun disk(rad: Float, step: Int): IntArray {
        val l = ArrayList<Int>()
        val ri = rad.toInt()
        var dy = -ri
        while (dy <= ri) {
            var dx = -ri
            while (dx <= ri) {
                if (dx * dx + dy * dy <= rad * rad) { l.add(dx); l.add(dy) }
                dx += step
            }
            dy += step
        }
        return l.toIntArray()
    }

    private fun blur(a: FloatArray, w: Int, h: Int) {
        val t = FloatArray(a.size)
        repeat(4) {
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    val l = a[row + max(0, x - 1)]; val c = a[row + x]; val r = a[row + min(w - 1, x + 1)]
                    t[row + x] = 0.25f * l + 0.5f * c + 0.25f * r
                }
            }
            for (y in 0 until h) {
                val up = max(0, y - 1) * w; val cu = y * w; val dn = min(h - 1, y + 1) * w
                for (x in 0 until w) a[cu + x] = 0.25f * t[up + x] + 0.5f * t[cu + x] + 0.25f * t[dn + x]
            }
        }
    }

    /** Finds all balls inside the calibrated table rectangle using a circle Hough transform. */
    fun detect(f: Frame, c: Calib): List<Ball> {
        val r = c.ball
        // balls resting on a cushion have their centre exactly on the calibrated line: look a bit beyond it so they are not cut in half
        val mg = 0.6f * r
        val x0 = max(1, (c.l - mg).toInt()); val y0 = max(1, (c.t - mg).toInt())
        val x1 = min(f.w - 2, (c.r + mg).toInt()); val y1 = min(f.h - 2, (c.b + mg).toInt())
        val W = x1 - x0 + 1; val H = y1 - y0 + 1
        if (W < 60 || H < 60 || r < 4f) return emptyList()

        // cloth colour = per-channel median of a coarse grid
        val rs = ArrayList<Int>(); val gs = ArrayList<Int>(); val bs = ArrayList<Int>()
        var yy = 0
        while (yy < H) {
            var xx = 0
            while (xx < W) {
                val p = f.at(x0 + xx, y0 + yy)
                if (!isOv(p)) { rs.add((p shr 16) and 255); gs.add((p shr 8) and 255); bs.add(p and 255) }
                xx += 17
            }
            yy += 17
        }
        if (rs.isEmpty()) return emptyList()
        rs.sort(); gs.sort(); bs.sort()
        val cr = rs[rs.size / 2]; val cg = gs[gs.size / 2]; val cb = bs[bs.size / 2]
        val clothRgb = (0xFF shl 24) or (cr shl 16) or (cg shl 8) or cb

        // local copy, overlay pixels replaced by cloth colour
        val px = IntArray(W * H)
        for (y in 0 until H) {
            val row = (y0 + y) * f.stride + x0
            for (x in 0 until W) {
                val p = f.px[row + x]
                px[y * W + x] = if (isOv(p)) clothRgb else p
            }
        }

        // Hough voting: every edge pixel votes for centres at distance r along its gradient
        val acc = FloatArray(W * H)
        val radii = floatArrayOf(r - 1f, r, r + 1f)
        val shifts = intArrayOf(16, 8, 0)
        for (y in 1 until H - 1) {
            for (x in 1 until W - 1) {
                val i = y * W + x
                var bgx = 0f; var bgy = 0f; var bm = 0f
                for (sh in shifts) {
                    val gx = (((px[i - W + 1] shr sh) and 255) + 2 * ((px[i + 1] shr sh) and 255) + ((px[i + W + 1] shr sh) and 255) -
                        ((px[i - W - 1] shr sh) and 255) - 2 * ((px[i - 1] shr sh) and 255) - ((px[i + W - 1] shr sh) and 255)) / 8f
                    val gy = (((px[i + W - 1] shr sh) and 255) + 2 * ((px[i + W] shr sh) and 255) + ((px[i + W + 1] shr sh) and 255) -
                        ((px[i - W - 1] shr sh) and 255) - 2 * ((px[i - W] shr sh) and 255) - ((px[i - W + 1] shr sh) and 255)) / 8f
                    val m = gx * gx + gy * gy
                    if (m > bm) { bm = m; bgx = gx; bgy = gy }
                }
                if (bm < 625f) continue
                val mag = sqrt(bm); val ux = bgx / mag; val uy = bgy / mag
                for (s in -1..1 step 2) for (rr in radii) {
                    val vx = (x + s * rr * ux).roundToInt(); val vy = (y + s * rr * uy).roundToInt()
                    if (vx in 0 until W && vy in 0 until H) acc[vy * W + vx] += 1f
                }
            }
        }
        blur(acc, W, H)

        val thr = 0.8f * r
        val peaks = ArrayList<Pair<Float, Int>>()
        for (i in acc.indices) if (acc[i] >= thr) peaks.add(Pair(acc[i], i))
        peaks.sortByDescending { it.first }
        val acc2 = ArrayList<IntArray>()
        for ((_, idx) in peaks) {
            val cx = idx % W; val cy = idx / W
            if (acc2.none { hypot((it[0] - cx).toFloat(), (it[1] - cy).toFloat()) < 1.5f * r }) acc2.add(intArrayOf(cx, cy))
            if (acc2.size > 32) break
        }

        val inner = disk(r * 0.7f, 2)
        val off = disk(r * 0.85f, 1)
        val ring2 = (r * 0.55f) * (r * 0.55f)
        class Cn(val x: Float, val y: Float, val wf: Float, val wfo: Float, val kind: Int, val col: Float)
        val cns = ArrayList<Cn>()
        for (a in acc2) {
            val cx = a[0]; val cy = a[1]
            // a ball centre can never be outside the calibrated rectangle (rejects pocket / cushion artefacts in the margin)
            val ax = x0 + cx; val ay = y0 + cy
            if (ax < c.l - 0.4f * r || ax > c.r + 0.4f * r || ay < c.t - 0.4f * r || ay > c.b + 0.4f * r) continue
            // the inside must be filled (rejects the hollow aim ring and background circles)
            var fgc = 0; var tot = 0; var i = 0
            while (i < inner.size) {
                val x = cx + inner[i]; val y = cy + inner[i + 1]; i += 2
                if (x < 0 || y < 0 || x >= W || y >= H) continue
                val p = px[y * W + x]
                if (p == clothRgb) continue
                tot++
                val dr = ((p shr 16) and 255) - cr; val dg = ((p shr 8) and 255) - cg; val db = (p and 255) - cb
                if (dr * dr + dg * dg + db * db > 3025) fgc++
            }
            if (tot == 0 || fgc.toFloat() / tot < 0.6f) continue

            // white fraction of the whole ball (wh/n) and of its outer ring only (who/no).
            // A plain ball only has its number-circle in the middle, a striped ball is white out to the rim.
            var wh = 0; var n = 0; var who = 0; var no = 0; var darkSum = 0L; var nw = 0; var chrom = 0
            i = 0
            while (i < off.size) {
                val dx = off[i]; val dy = off[i + 1]
                val x = cx + dx; val y = cy + dy; i += 2
                if (x < 0 || y < 0 || x >= W || y >= H) continue
                val p = px[y * W + x]
                if (p == clothRgb) continue
                val outer = (dx * dx + dy * dy).toFloat() > ring2
                n++; if (outer) no++
                if (white(p)) { wh++; if (outer) who++ }
                else {
                    val pr = (p shr 16) and 255; val pg = (p shr 8) and 255; val pb = p and 255
                    darkSum += max(max(pr, pg), pb); nw++
                    if (max(pr, max(pg, pb)) - min(pr, min(pg, pb)) > 70) chrom++
                }
            }
            val wf = if (n == 0) 0f else wh / n.toFloat()
            val wfo = if (no == 0) 0f else who / no.toFloat()
            val avgMax = if (nw == 0) 255f else darkSum.toFloat() / nw
            // coloured pixels: the cue ball has (almost) none, a striped ball always has its coloured band
            val col = if (n == 0) 0f else chrom / n.toFloat()
            val kind = when {
                wf > 0.7f && wfo > 0.55f && col < 0.12f -> 0
                avgMax < 85f && wf < 0.5f -> 3
                wfo > 0.22f || (wf > 0.45f && wfo > 0.15f) -> 2
                else -> 1
            }
            cns.add(Cn((x0 + cx).toFloat(), (y0 + cy).toFloat(), wf, wfo, kind, col))
        }
        // exactly one cue ball: the whitest one. Any other "white" ball is a striped ball - never throw a ball away.
        var cueI = -1
        for (k in cns.indices) if (cns[k].kind == 0 && (cueI < 0 || cns[k].wf + cns[k].wfo - 2f * cns[k].col > cns[cueI].wf + cns[cueI].wfo - 2f * cns[cueI].col)) cueI = k
        if (cueI < 0) {
            // fallback: the whitest, least coloured candidate (lighting can push the cue ball just under the thresholds)
            var bestS = 0f
            for (k in cns.indices) {
                val sc = cns[k].wf + cns[k].wfo - 2f * cns[k].col
                if (cns[k].wf > 0.55f && cns[k].col < 0.2f && cns[k].kind != 3 && sc > bestS) { bestS = sc; cueI = k }
            }
        }
        val out = ArrayList<Ball>()
        if (cueI >= 0) out.add(Ball(cns[cueI].x, cns[cueI].y, 0))
        for (k in cns.indices) {
            if (k == cueI) continue
            val c0 = cns[k]
            out.add(Ball(c0.x, c0.y, if (c0.kind == 0) 2 else c0.kind))
        }
        return out
    }

    /** Angle (radians, screen coords) of the game's white aim line. Our own overlay pixels are ignored. */
    fun aimAngle(f: Frame, cue: Ball, r: Float, hint: Float?): Float? {
        val d0 = r * 2.4f; val len = 230
        val n = 1440
        val score = FloatArray(n)
        for (k in 0 until n) {
            val th = k * (2.0 * PI / n)
            val cs = cos(th); val sn = sin(th)
            var hit = 0; var cnt = 0
            var d = d0.toDouble()
            while (d < d0 + len) {
                val x = (cue.x + d * cs).roundToInt(); val y = (cue.y + d * sn).roundToInt()
                if (x in 0 until f.w && y in 0 until f.h) {
                    val p = f.at(x, y)
                    if (!isOv(p)) { cnt++; if (aimWhite(p)) hit++ }
                }
                d += 2.0
            }
            score[k] = if (cnt >= 20) hit.toFloat() / cnt else 0f
        }
        var bk = 0
        for (k in 0 until n) if (score[k] > score[bk]) bk = k
        if (score[bk] < 0.6f) return null
        val ok = (bk + n / 2) % n
        if (hint != null && score[ok] >= 0.6f * score[bk]) {
            val a1 = bk * 2.0 * PI / n; val a2 = ok * 2.0 * PI / n
            fun diff(a: Double): Double { var d = a - hint; while (d > PI) d -= 2 * PI; while (d < -PI) d += 2 * PI; return abs(d) }
            if (diff(a2) < diff(a1)) bk = ok
        }
        val th0 = bk * 2.0 * PI / n
        val cs = cos(th0); val sn = sin(th0)
        var sw = 0.0; var sa = 0.0
        var d = d0.toDouble()
        while (d < d0 + len) {
            for (o in -5..5) {
                val x = (cue.x + d * cs - o * sn).roundToInt(); val y = (cue.y + d * sn + o * cs).roundToInt()
                if (x in 0 until f.w && y in 0 until f.h && aimWhite(f.at(x, y))) {
                    var da = atan2(y - cue.y.toDouble(), x - cue.x.toDouble()) - th0
                    while (da > PI) da -= 2 * PI; while (da < -PI) da += 2 * PI
                    sa += da * d * d; sw += d * d
                }
            }
            d += 1.0
        }
        return (if (sw > 0) th0 + sa / sw else th0).toFloat()
    }
}
