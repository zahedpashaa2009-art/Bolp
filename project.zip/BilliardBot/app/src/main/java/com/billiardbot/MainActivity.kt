package com.billiardbot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * d).toInt(), (40 * d).toInt(), (20 * d).toInt(), (20 * d).toInt())
        }
        fun add(v: View) { root.addView(v) }
        add(TextView(this).apply { text = "BilliardBot (مشاور شات)"; textSize = 24f })
        status = TextView(this).apply { textSize = 15f; setPadding(0, (12 * d).toInt(), 0, (12 * d).toInt()) }
        add(status)
        fun button(t: String, f: () -> Unit) = add(Button(this).apply { text = t; setOnClickListener { f() } })
        button("۱) اجازه نمایش روی برنامه‌های دیگر") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("۲) شروع (ضبط صفحه + دکمه‌های شناور)") {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), 7)
        }
        add(TextView(this).apply {
            textSize = 14f; setPadding(0, (16 * d).toInt(), 0, 0)
            text = "بعد از شروع، بازی را باز کن و یک بار دکمه CAL را بزن:\n" +
                "گوشه‌های میز و بالا/پایین نوار قدرت را لمس کن، بعد توپ‌ها را چک کن و ذخیره بزن.\n\n" +
                "دکمه 1-7 / 9-15 / ALL نوع توپ تو را عوض می‌کند.\n" +
                "AUTO / TRK: در حالت AUTO بهترین ضربه (مستقیم، بانک، کمبو، کیس، کیک) پیشنهاد می‌شود؛ در حالت TRK فقط تریک شات (بانک، کمبو، کیس، کیک) و خود برنامه بهترین نوع را انتخاب می‌کند.\n" +
                "👁 برچسب تشخیص توپ‌ها را روی میز نشان می‌دهد (W سفید، S ساده، T راه‌راه، 8) تا اشتباه تشخیص را ببینی.\n" +
                "▶ مشاور را روشن/خاموش می‌کند. بعد از هر ضربه خودش بهترین شات را با خط سبز نشان می‌دهد.\n" +
                "↻ شات بعدیِ پیشنهادی را نشان می‌دهد.\n" +
                "خط پررنگ: مسیر توپی که می‌افتد.\n" +
                "DET: جزئیات اضافه (مسیر توپ سفید بعد از برخورد، توپ‌های دیگر) را روشن/خاموش می‌کند؛ پیش‌فرض خاموش و صفحه تمیز است.\n" +
                "خود بازی را خودت می‌زنی؛ برنامه هیچ‌چیز را لمس نمی‌کند."
        })
        setContentView(ScrollView(this).apply { addView(root) })
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        status.text = "نمایش روی برنامه‌ها: ${if (Settings.canDrawOverlays(this)) "✔" else "✘"}"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
