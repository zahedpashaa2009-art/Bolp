package com.billiardbot

import kotlin.math.*

/** Result of one simulated shot. Index 0 = cue ball, 1..n-1 = the other balls (same order as the list given to run()). */
class SimRes(
    val n: Int,
    val first: Int,                 // first object ball the cue ball touched (-1 = none)
    val fcx: Float, val fcy: Float, // cue-ball centre at that first touch
    val cuePreCount: Int,           // number of cue trace points up to and including the first touch
    val cueScratch: Boolean,
    val railAfter: Boolean,         // some ball hit a cushion after the first touch
    val pocketed: IntArray,         // ball indices, in order of falling
    val pocketIdx: IntArray,        // pocket of each fallen ball
    val entry: FloatArray,          // how straight each ball entered its pocket (cosine, 1 = dead straight)
    val src: IntArray,              // who set each ball in motion (0 = cue, >0 other ball, -1 never moved)
    val hits: IntArray,             // collisions a ball had after it was already moving
    val rails: IntArray,            // cushion contacts of each ball
    val cueRailsBefore: Int,        // cue-ball cushion contacts before it touched any ball
    val fx: FloatArray, val fy: FloatArray, val alive: BooleanArray,
    val trace: Array<ArrayList<P>>?
)

/**
 * Small 2-D billiards engine: exact (event based) ball-ball and ball-cushion collisions,
 * constant rolling friction, pockets. No spin. Used to try every candidate shot "in the head" like a player does.
 */
class Sim(private val g: Geo, private val ps: Float, pkScale: Float = 1f) {
    private val r = g.rad
    private val d2 = 4f * r * r
    private val prCorner = 1.6f * r * pkScale   // slightly tighter than before: fewer "phantom" pockets
    private val prSide = 1.3f * r * pkScale
    private val FR = 1f        // rolling deceleration (px/s^2) - only relative distances matter
    private val RB = 0.96f     // ball-ball restitution
    private val RR = 0.78f     // cushion restitution

    /** Distance (px) the cue ball would roll with no collisions at this power-bar fraction. */
    fun travel(power: Float): Float {
        val k = (power - 0.2f) / (0.8f * ps)
        return max(0.03f, k) * 1.1f * g.diag
    }

    private fun pocketR(i: Int) = if (g.pockets[i].side) prSide else prCorner

    /** [quick] = stop as soon as the first object ball falls (enough to know that an aim works). */
    fun run(cue: P, objs: List<Ball>, angle: Float, power: Float, trace: Boolean, quick: Boolean = false): SimRes {
        val n = objs.size + 1
        val x = FloatArray(n); val y = FloatArray(n)
        val vx = FloatArray(n); val vy = FloatArray(n)
        val alive = BooleanArray(n) { true }
        x[0] = cue.x; y[0] = cue.y
        for (i in 1 until n) { x[i] = objs[i - 1].x; y[i] = objs[i - 1].y }
        val v0 = sqrt(2f * FR * travel(power))
        vx[0] = cos(angle) * v0; vy[0] = sin(angle) * v0

        val src = IntArray(n) { -1 }; val hits = IntArray(n); val rails = IntArray(n)
        var first = -1; var fcx = 0f; var fcy = 0f; var cuePre = -1
        var railAfter = false; var scratch = false; var cueRailsBefore = 0
        val pk = ArrayList<Int>(); val pki = ArrayList<Int>(); val pke = ArrayList<Float>()
        val tr: Array<ArrayList<P>>? = if (trace) Array(n) { ArrayList<P>() } else null
        if (tr != null) for (i in 0 until n) tr[i].add(P(x[i], y[i]))

        var steps = 0
        var done = false
        while (steps < 3000 && !done) {
            steps++
            var vmax = 0f
            for (i in 0 until n) if (alive[i]) { val s = hypot(vx[i], vy[i]); if (s > vmax) vmax = s }
            if (vmax < 0.01f) break
            val dt = min(0.08f, 0.35f * r / vmax)
            var rem = dt
            var guard = 0
            while (rem > 1e-7f && guard < 40 && !done) {
                guard++
                var bt = rem; var kind = 0; var ei = -1; var ej = -1
                for (i in 0 until n) {
                    if (!alive[i]) continue
                    val mi = vx[i] != 0f || vy[i] != 0f
                    if (mi) {
                        // cushions (ball centre may not leave [il..ir] x [it..ib])
                        if (vx[i] < 0f) { val t = max(0f, (g.il - x[i]) / vx[i]); if (t < bt) { bt = t; kind = 2; ei = i; ej = 0 } }
                        else if (vx[i] > 0f) { val t = max(0f, (g.ir - x[i]) / vx[i]); if (t < bt) { bt = t; kind = 2; ei = i; ej = 1 } }
                        if (vy[i] < 0f) { val t = max(0f, (g.it - y[i]) / vy[i]); if (t < bt) { bt = t; kind = 2; ei = i; ej = 2 } }
                        else if (vy[i] > 0f) { val t = max(0f, (g.ib - y[i]) / vy[i]); if (t < bt) { bt = t; kind = 2; ei = i; ej = 3 } }
                        // pockets
                        val sp = vx[i] * vx[i] + vy[i] * vy[i]
                        for (q in g.pockets.indices) {
                            val pr = pocketR(q)
                            val dx = x[i] - g.pockets[q].pos.x; val dy = y[i] - g.pockets[q].pos.y
                            val c0 = dx * dx + dy * dy - pr * pr
                            val b = dx * vx[i] + dy * vy[i]
                            var t = -1f
                            if (c0 <= 0f) t = 0f
                            else if (b < 0f) { val disc = b * b - sp * c0; if (disc >= 0f) t = (-b - sqrt(disc)) / sp }
                            if (t >= 0f && t < bt) { bt = t; kind = 3; ei = i; ej = q }
                        }
                    }
                    // ball - ball
                    for (j in i + 1 until n) {
                        if (!alive[j]) continue
                        val mj = vx[j] != 0f || vy[j] != 0f
                        if (!mi && !mj) continue
                        val dx = x[j] - x[i]; val dy = y[j] - y[i]
                        val wx = vx[j] - vx[i]; val wy = vy[j] - vy[i]
                        val a = wx * wx + wy * wy
                        if (a < 1e-9f) continue
                        val b = dx * wx + dy * wy
                        if (b >= 0f) continue
                        val c = dx * dx + dy * dy - d2
                        var t: Float
                        if (c <= 0f) t = 0f
                        else { val disc = b * b - a * c; if (disc < 0f) continue; t = (-b - sqrt(disc)) / a }
                        if (t < bt) { bt = t; kind = 1; ei = i; ej = j }
                    }
                }
                // advance everybody to the event
                if (bt > 0f) for (i in 0 until n) if (alive[i]) { x[i] += vx[i] * bt; y[i] += vy[i] * bt }
                rem -= bt
                when (kind) {
                    1 -> {
                        val i = ei; val j = ej
                        val dx = x[j] - x[i]; val dy = y[j] - y[i]
                        val dist = max(1e-4f, hypot(dx, dy))
                        val nx = dx / dist; val ny = dy / dist
                        if (dist < 2f * r) { val push = (2f * r - dist) / 2f; x[i] -= nx * push; y[i] -= ny * push; x[j] += nx * push; y[j] += ny * push }
                        val mi = vx[i] != 0f || vy[i] != 0f
                        val mj = vx[j] != 0f || vy[j] != 0f
                        val vn = (vx[i] - vx[j]) * nx + (vy[i] - vy[j]) * ny
                        if (vn > 0f) {
                            val imp = (1f + RB) * 0.5f * vn
                            vx[i] -= imp * nx; vy[i] -= imp * ny; vx[j] += imp * nx; vy[j] += imp * ny
                            if (mi) hits[i]++
                            if (mj) hits[j]++
                            if (!mi && src[i] < 0) src[i] = j
                            if (!mj && src[j] < 0) src[j] = i
                            if (first < 0 && (i == 0 || j == 0)) {
                                first = if (i == 0) j else i
                                fcx = x[0]; fcy = y[0]
                            }
                        }
                        if (tr != null) { tr[i].add(P(x[i], y[i])); tr[j].add(P(x[j], y[j])); if (cuePre < 0 && first >= 0) cuePre = tr[0].size }
                    }
                    2 -> {
                        val i = ei
                        when (ej) {
                            0 -> { x[i] = g.il; vx[i] = -vx[i] * RR }
                            1 -> { x[i] = g.ir; vx[i] = -vx[i] * RR }
                            2 -> { y[i] = g.it; vy[i] = -vy[i] * RR }
                            else -> { y[i] = g.ib; vy[i] = -vy[i] * RR }
                        }
                        rails[i]++
                        if (first >= 0) railAfter = true
                        else if (i == 0) cueRailsBefore++
                        if (tr != null) tr[i].add(P(x[i], y[i]))
                    }
                    3 -> {
                        val i = ei; val q = ej
                        val sp = hypot(vx[i], vy[i])
                        val ax = g.pockets[q].axis
                        val ent = if (sp < 1e-4f) 1f else (vx[i] * ax.x + vy[i] * ax.y) / sp
                        alive[i] = false
                        vx[i] = 0f; vy[i] = 0f
                        if (first >= 0) railAfter = true
                        if (i == 0) scratch = true else { pk.add(i); pki.add(q); pke.add(ent); if (quick && first >= 0) done = true }
                        if (tr != null) tr[i].add(P(g.pockets[q].pos.x, g.pockets[q].pos.y))
                    }
                    else -> { }
                }
            }
            if (done) break
            if (rem > 1e-7f) for (i in 0 until n) if (alive[i]) { x[i] += vx[i] * rem; y[i] += vy[i] * rem }
            // rolling friction
            val dv = FR * dt
            for (i in 0 until n) {
                if (!alive[i]) continue
                val s = hypot(vx[i], vy[i])
                if (s == 0f) continue
                val ns = s - dv
                if (ns <= 0f) { vx[i] = 0f; vy[i] = 0f } else { val k = ns / s; vx[i] *= k; vy[i] *= k }
            }
        }
        if (tr != null) for (i in 0 until n) if (alive[i]) {
            val l = tr[i].last()
            if (hypot(l.x - x[i], l.y - y[i]) > 0.5f) tr[i].add(P(x[i], y[i]))
        }
        if (cuePre < 0) cuePre = tr?.get(0)?.size ?: 0
        return SimRes(
            n, first, fcx, fcy, cuePre, scratch, railAfter,
            pk.toIntArray(), pki.toIntArray(), pke.toFloatArray(),
            src, hits, rails, cueRailsBefore, x, y, alive, tr
        )
    }
}
