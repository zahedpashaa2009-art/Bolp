package com.billiardbot

import android.graphics.Color
import kotlin.math.hypot

object Ov { val COLOR: Int = Color.rgb(0, 255, 64) }

data class P(val x: Float, val y: Float) {
    operator fun plus(o: P) = P(x + o.x, y + o.y)
    operator fun minus(o: P) = P(x - o.x, y - o.y)
    operator fun times(k: Float) = P(x * k, y * k)
    fun len() = hypot(x, y)
    fun norm(): P { val l = len(); return if (l < 1e-6f) P(0f, 0f) else P(x / l, y / l) }
    fun dot(o: P) = x * o.x + y * o.y
}

/** kind: 0 = cue, 1 = solid, 2 = stripe, 3 = eight */
data class Ball(val x: Float, val y: Float, val kind: Int) {
    val p: P get() = P(x, y)
}

class Frame(val w: Int, val h: Int, val stride: Int, val px: IntArray) {
    fun at(x: Int, y: Int) = px[y * stride + x]
}

data class Advice(
    val cue: P, val gh: P, val ball: P?, val legs: List<Pair<P, P>>, val pocket: P?,
    val power: Float, val angle: Float, val title: String, val hard: String,
    val cuePre: List<Pair<P, P>> = emptyList(),    // cue ball path up to the first touch
    val cuePost: List<Pair<P, P>> = emptyList(),   // where the cue ball goes afterwards
    val extra: List<Pair<P, P>> = emptyList(),     // other balls that get moved (combo / kiss partners)
    val marks: List<P> = emptyList(),              // contact points on the way
    val tol: Float = 0f,                           // angle tolerance (degrees, +/-)
    val info: String = "",
    val helper: List<Pair<P, P>> = emptyList()      // first leg of the ball that drives the target (combo)
)
