package com.billiardbot

import android.content.Context
import android.graphics.*
import android.view.View

/** Full-screen, touch-transparent layer that draws the recommended shot on top of the game. */
class AdviceView(ctx: Context, private val cal: Calib) : View(ctx) {
    private var adv: Advice? = null
    private var lines: List<String> = emptyList()
    private var balls: List<Ball>? = null
    private val line = Paint().apply { color = Ov.COLOR; style = Paint.Style.STROKE; strokeWidth = 5f; isAntiAlias = false }
    private val dash = Paint(line).apply { pathEffect = DashPathEffect(floatArrayOf(14f, 14f), 0f) }
    private val thick = Paint(line).apply { strokeWidth = 9f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.RIGHT }
    private val bg = Paint().apply { color = 0xCC000000.toInt() }
    private val thin = Paint(line).apply { strokeWidth = 3f; pathEffect = DashPathEffect(floatArrayOf(6f, 10f), 0f) }
    private val lbl = Paint().apply { color = Ov.COLOR; isAntiAlias = false; isFakeBoldText = true }

    /** false = clean view (only what you need to aim); true = also cue-ball path after the hit, moved balls, contact marks. */
    var detail = false
        set(v) { field = v; invalidate() }

    fun set(a: Advice?, l: List<String>) { adv = a; lines = l; invalidate() }
    fun setBalls(b: List<Ball>?) { balls = b; invalidate() }

    override fun onDraw(c: Canvas) {
        val loc = IntArray(2); getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        val r = cal.ball
        val a = adv
        if (a != null) {
            // cue ball path up to the first touch (may bounce off a cushion first for kick shots)
            if (a.cuePre.isEmpty()) c.drawLine(a.cue.x, a.cue.y, a.gh.x, a.gh.y, dash)
            else for ((p, q) in a.cuePre) c.drawLine(p.x, p.y, q.x, q.y, dash)
            c.drawCircle(a.gh.x, a.gh.y, r, line)
            // the ball that drives the target (combo) and the ball that falls
            for ((p, q) in a.helper) c.drawLine(p.x, p.y, q.x, q.y, line)
            for ((p, q) in a.legs) c.drawLine(p.x, p.y, q.x, q.y, line)
            a.pocket?.let { c.drawCircle(it.x, it.y, r * 0.7f, line) }
            if (detail) {
                for ((p, q) in a.cuePost) c.drawLine(p.x, p.y, q.x, q.y, thin)
                for ((p, q) in a.extra) c.drawLine(p.x, p.y, q.x, q.y, thin)
                for (m in a.marks) c.drawCircle(m.x, m.y, r * 0.55f, line)
            }
            // power marker on the power bar
            val px = cal.pTopX + (cal.pBotX - cal.pTopX) * a.power
            val py = cal.pTopY + (cal.pBotY - cal.pTopY) * a.power
            c.drawLine(px - 32f, py, px + 32f, py, thick)
            val ts = (cal.r - cal.l) * 0.045f
            txt.textSize = ts; txt.textAlign = Paint.Align.LEFT
            val label = "${(a.power * 100).toInt()}%"
            val w = txt.measureText(label)
            c.drawRect(px + 38f, py - ts, px + 50f + w, py + ts * 0.35f, bg)
            c.drawText(label, px + 44f, py, txt)
        }
        balls?.let { bl ->
            val names = arrayOf("W", "S", "T", "8")
            lbl.textSize = r * 1.3f
            for (b in bl) {
                c.drawCircle(b.x, b.y, r * 1.18f, thin)
                c.drawText(names[b.kind], b.x - r * 0.4f, b.y - r * 1.35f, lbl)
            }
        }
        if (lines.isNotEmpty()) {
            val ts = (cal.r - cal.l) * 0.034f
            txt.textSize = ts; txt.textAlign = Paint.Align.RIGHT
            var mw = 0f
            for (s in lines) mw = maxOf(mw, txt.measureText(s))
            val h = lines.size * ts * 1.35f + 12f
            val top = maxOf(4f, cal.t - h - 8f)
            val right = cal.r
            c.drawRect(right - mw - 24f, top, right, top + h, bg)
            var y = top + ts * 1.1f
            for (s in lines) { c.drawText(s, right - 10f, y, txt); y += ts * 1.35f }
        }
    }
}
